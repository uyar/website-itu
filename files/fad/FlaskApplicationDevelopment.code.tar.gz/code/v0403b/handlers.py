from flask import Blueprint, redirect, render_template, url_for
from flask import current_app, request

from datetime import datetime

from forms import MovieEditForm
from movie import Movie


site = Blueprint('site', __name__)


@site.route('/')
def home_page():
    now = datetime.now()
    day = now.strftime('%A')
    return render_template('home.html', day_name=day)


@site.route('/movies', methods=['GET', 'POST'])
def movies_page():
    if request.method == 'GET':
        movies = current_app.store.get_movies()
        return render_template('movies.html', movies=sorted(movies.items()))
    else:
        movie_ids = request.form.getlist('movie_ids')
        for movie_id in movie_ids:
            current_app.store.delete_movie(int(movie_id))
        return redirect(url_for('site.movies_page'))


@site.route('/movies/add', methods=['GET', 'POST'])
def movie_add_page():
    form = MovieEditForm()
    if form.validate_on_submit():
        title = form.data['title']
        year = form.data['year']
        movie = Movie(title, year=year)
        current_app.store.add_movie(movie)
        return redirect(url_for('site.movie_page', movie_id=movie._id))
    return render_template('movie_edit.html', form=form)


@site.route('/movie/<int:movie_id>')
def movie_page(movie_id):
    movie = current_app.store.get_movie(movie_id)
    return render_template('movie.html', movie=movie)


@site.route('/movie/<int:movie_id>/edit', methods=['GET', 'POST'])
def movie_edit_page(movie_id):
    movie = current_app.store.get_movie(movie_id)
    form = MovieEditForm()
    if form.validate_on_submit():
        movie.title = form.data['title']
        movie.year = form.data['year']
        current_app.store.update_movie(movie)
        return redirect(url_for('site.movie_page', movie_id=movie._id))
    form.title.data = movie.title
    form.year.data = movie.year if movie.year else ''
    return render_template('movie_edit.html', form=form)
