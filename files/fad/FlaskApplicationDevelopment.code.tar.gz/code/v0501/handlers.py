from flask import Blueprint, abort, flash, redirect, render_template, url_for
from flask import current_app, request
from flask_login import current_user, login_required, login_user, logout_user

from datetime import datetime
from passlib.apps import custom_app_context as pwd_context

from forms import LoginForm, MovieEditForm
from movie import Movie
from user import get_user


site = Blueprint('site', __name__)


@site.route('/')
def home_page():
    now = datetime.now()
    day = now.strftime('%A')
    return render_template('home.html', day_name=day)


@site.route('/login', methods=['GET', 'POST'])
def login_page():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.data['username']
        user = get_user(username)
        if user is not None:
            password = form.data['password']
            if pwd_context.verify(password, user.password):
                login_user(user)
                flash('You have logged in.')
                next_page = request.args.get('next', url_for('site.home_page'))
                return redirect(next_page)
        flash('Invalid credentials.')
    return render_template('login.html', form=form)


@site.route('/logout')
def logout_page():
    logout_user()
    flash('You have logged out.')
    return redirect(url_for('site.home_page'))


@site.route('/movies', methods=['GET', 'POST'])
def movies_page():
    if request.method == 'GET':
        movies = current_app.store.get_movies()
        return render_template('movies.html', movies=sorted(movies.items()))
    else:
        if not current_user.is_admin:
            abort(401)
        movie_ids = request.form.getlist('movie_ids')
        for movie_id in movie_ids:
            current_app.store.delete_movie(int(movie_id))
        flash('%d movies deleted.' % len(movie_ids))
        return redirect(url_for('site.movies_page'))


@site.route('/movies/add', methods=['GET', 'POST'])
@login_required
def movie_add_page():
    if not current_user.is_admin:
        abort(401)
    form = MovieEditForm()
    if form.validate_on_submit():
        title = form.data['title']
        year = form.data['year']
        movie = Movie(title, year=year)
        current_app.store.add_movie(movie)
        flash('Movie added.')
        return redirect(url_for('site.movie_page', movie_id=movie._id))
    return render_template('movie_edit.html', form=form)


@site.route('/movie/<int:movie_id>')
def movie_page(movie_id):
    movie = current_app.store.get_movie(movie_id)
    return render_template('movie.html', movie=movie)


@site.route('/movie/<int:movie_id>/edit', methods=['GET', 'POST'])
@login_required
def movie_edit_page(movie_id):
    movie = current_app.store.get_movie(movie_id)
    form = MovieEditForm()
    if form.validate_on_submit():
        movie.title = form.data['title']
        movie.year = form.data['year']
        current_app.store.update_movie(movie)
        flash('Movie data updated.')
        return redirect(url_for('site.movie_page', movie_id=movie._id))
    form.title.data = movie.title
    form.year.data = movie.year if movie.year else ''
    return render_template('movie_edit.html', form=form)
