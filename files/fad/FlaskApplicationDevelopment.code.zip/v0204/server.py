from flask import Flask

from handlers import site


def create_app():
    app = Flask(__name__)
    app.register_blueprint(site)
    return app


def main():
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)


if __name__ == '__main__':
    main()
