from flask import Flask

from handlers import site
from movie import Movie
from store import Store


def create_app():
    app = Flask(__name__)
    app.config.from_object('settings')
    app.register_blueprint(site)

    app.store = Store()
    app.store.add_movie(Movie('The Shining', year=1980))
    app.store.add_movie(Movie('Barton Fink', year=1991))

    return app


def main():
    app = create_app()
    app.run(host='0.0.0.0')


if __name__ == '__main__':
    main()
